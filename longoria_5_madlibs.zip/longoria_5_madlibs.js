var name = prompt("Pick a name");

var name2 = prompt("Pick another name");

var hours= prompt("Pick a number");

var vehicle= prompt("Pick a car");

var place=prompt("Pick a place");

var noun1=prompt("Pick a noun");

var verb1=prompt("pick a verb");

var verb2=prompt("Pick another verb");

var verb3=prompt("Pick anoher verb");

var adj1=prompt("Pick an adjective");

var adj2="funny";

var adj3="inexpensive";

var prep1=" around";


document.write("Last month, " +name +" went to Disney " + "World with " +name2 +".");
document.write(" They traveled for " +hours +" hours by " +vehicle +".")
document.write(" Finally they got there and it was very " +adj1 +", ")
document.write("and there were " +adj2 +" characters " +verb1 +prep1 +".")
document.write(" People laughing everywhere.")
document.write(" I wish it would have been more " +adj3 +",")
document.write(" but we were " +verb2 +" anyways.")
document.write(" We also went on some " + " crazy ride, " +" called magic " +noun1 +". ")
document.write(name +" nearly fell off a ride and had to be " +verb3 +" by Mickey Mouse!")
document.write(" Later they went to the hotel and had a sleepover.")
document.write(" Next year, " +name2 +" wants to go to " +place +"," +" where they can have some more fun.")
