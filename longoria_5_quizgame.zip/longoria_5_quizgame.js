var one = prompt("What's Gabriela's last name?");

if (one == Longoria) {
    alert("This was just an easy one! It'll get harder ;) ");
} else { 
    alert("are you serious? wow just wow :(")
}

var two = prompt("Who are 2 of Gabriela's favorite singers?");

if (two == "Michael Jackson and Prince" ) {
    alert("its not that impressive kinda basic knowledge but whatever. ");
} else { 
    alert("I'm ashamed...You should know this one")
}

 var three = prompt("Does Gabriela know how to dance? Answer with true or false");

if (three == "true" ) {
    alert("Aye! You know me well!");
} else { 
    alert("and you've got this far how? :/")
}

  var four = prompt("Does Gabriela know how to sing? Answer with true or false");

if (four == "true" ) {
    alert("nailed it my dude!");
} else { 
    alert("are you done yet?")
}

  var five = prompt("Who's Gabriela's best friend?");

if (five == Taj  ) {
    alert("der ya go! ");
} else { 
    alert("c'mon man.. :/")
}

  var six = prompt("Is Gabriela Old School or New School?");

if (six == old school  ) {
    alert("You guessed it! ");
} else { 
    alert("tsk tsk tsk... :(")
}

  var seven = prompt("What's Gabriela's dream job?");

if (seven == professional dancer  ) {
    alert("Yaasss!! ");
} else { 
    alert("Not even close! ")
}

  var eight = prompt("What's Gabriela's favorite color?");

if (eight == red  ) {
    alert("Yup you got it! ");
} else { 
    alert("Nope, Try Again. ")
}

  var nine = prompt("What's Gabriela's favorite food?");

if (nine == pizza  ) {
    alert("PIIIZZAAA!!! ");
} else { 
    alert("This is a bummer...")
}

  var ten = prompt("What's Gabriela's favorite TV Show?");

if (ten == Full House  ) {
    alert("You got it dude! :D You're all done! Good Job!");
} else { 
    alert("Whata shame..")
}